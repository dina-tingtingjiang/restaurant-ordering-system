package com.lzy.liujing.restaurant.utils;

import org.junit.Ignore;
import org.junit.Test;

public class createOrderCodeUtilTest {

    @Test
    @Ignore
    public void createOrderCode() {
        System.out.println(OrderCodeUtil.createOrderCode());
    }
}