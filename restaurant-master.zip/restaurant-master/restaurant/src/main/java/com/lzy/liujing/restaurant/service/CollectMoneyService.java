package com.lzy.liujing.restaurant.service;

/**
 * Created with IDEA
 * author:LiuJing
 * Date:2018/10/2
 * Time:15:15
 *
 * 收银管理业务逻辑接口
 */

public interface  CollectMoneyService {

}
