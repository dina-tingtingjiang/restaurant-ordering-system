package com.lzy.liujing.restaurant.service;

/**
 * Created with IDEA
 * author:LiuJing
 * Date:2018/10/2
 * Time:15:11
 *
 * 我的设置业务逻辑
 */

public interface MySettingsService {

}
