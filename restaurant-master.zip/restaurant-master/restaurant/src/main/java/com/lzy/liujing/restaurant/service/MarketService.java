package com.lzy.liujing.restaurant.service;

/**
 * Created with IDEA
 * author:LiuJing
 * Date:2018/10/2
 * Time:15:04
 *
 * 销售管理业务逻辑
 */

public interface MarketService {
}
