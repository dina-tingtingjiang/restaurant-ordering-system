package com.lzy.liujing.restaurant.service.Impl;

import com.lzy.liujing.restaurant.service.CollectMoneyService;
import org.springframework.stereotype.Service;

/**
 * Created with IDEA
 * author:LiuJing
 * Date:2018/10/2
 * Time:15:17
 *
 * 收银管理业务逻辑实现类
 */
@Service
public class CollectMoneyServiceImpl implements CollectMoneyService{

}
